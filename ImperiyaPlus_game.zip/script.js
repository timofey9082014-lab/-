const state=JSON.parse(localStorage.getItem("imperiya_state")||'{"balance":10000,"gems":0,"energy":100,"xp":0,"items":[]}');
const money=n=>n.toLocaleString("ru-RU");
function save(){localStorage.setItem("imperiya_state",JSON.stringify(state));render()}
function render(){document.querySelector("#balance").textContent=money(state.balance);document.querySelector("#gems").textContent=state.gems;document.querySelector("#energy").textContent=state.energy;document.querySelector("#xp").textContent=state.xp}
function event(text){const el=document.createElement("div");el.className="event";el.innerHTML=`🟢 <span>${text}</span><time>сейчас</time>`;document.querySelector("#eventsList").prepend(el)}
const modal=document.querySelector("#modal"), content=document.querySelector("#modalContent");
function openPage(page){
 if(page==="home"){window.scrollTo({top:0,behavior:"smooth"});return}
 modal.classList.remove("hidden");
 if(page==="market") content.innerHTML=`<h2>📈 Рынок</h2><p class="notice">Покупай товары и продавай их позже дороже.</p>
 ${[["🌾","Зерно",500],["🪵","Древесина",800],["⛏️","Железо",1200]].map((x,i)=>`<div class="shop-item"><span>${x[0]} <b>${x[1]}</b><br><small>${money(x[2])} монет</small></span><button class="buy" data-buy="${i}">Купить</button></div>`).join("")}`;
 if(page==="inventory") content.innerHTML=`<h2>🎒 Инвентарь</h2><div class="stat">${state.items.length} предметов</div><p class="notice">${state.items.length?state.items.map(x=>"• "+x).join("<br>"):"Пока пусто. Загляни на рынок!"}</p>`;
 if(page==="bank") content.innerHTML=`<h2>🏦 Банк</h2><p>Текущий баланс</p><div class="stat">🪙 ${money(state.balance)}</div><p class="notice">В будущей версии здесь появятся вклады, проценты и переводы.</p>`;
 if(page==="map") content.innerHTML=`<h2>🗺️ Карта</h2><p class="notice">Центральный регион открыт. Другие регионы разблокируются по мере развития.</p>`;
 document.querySelectorAll("[data-buy]").forEach(b=>b.onclick=()=>buy(+b.dataset.buy));
}
function buy(i){const items=[["Зерно",500],["Древесина",800],["Железо",1200]], [name,price]=items[i]; if(state.balance<price){alert("Недостаточно монет");return} state.balance-=price;state.items.push(name);state.xp=Math.min(100,state.xp+10);event(`Куплено: ${name}`);save();openPage("inventory")}
document.querySelector("#close").onclick=()=>modal.classList.add("hidden");
modal.onclick=e=>{if(e.target===modal)modal.classList.add("hidden")};
document.querySelectorAll("[data-page]").forEach(b=>b.onclick=()=>openPage(b.dataset.page));
document.querySelectorAll(".region").forEach(b=>b.onclick=()=>{if(b.classList.contains("locked"))alert("Этот регион пока закрыт.");else event("Вы выбрали Центральный регион.")});
render();